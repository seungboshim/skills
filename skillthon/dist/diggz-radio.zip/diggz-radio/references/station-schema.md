# Station JSON

`build_station.py`가 받는 형식이다.

```json
{
  "title": "Null Pointer, Warm Lights",
  "scene": "debug-loop",
  "steer": "cool-down",
  "task": "결제 콜백 재시도 버그 추적",
  "duration_minutes": 48,
  "energy": [42, 56, 38],
  "brief": "따뜻하고 일정한 질감, 낮은 가사 밀도, 중반만 살짝 상승",
  "discovery": {
    "source": "YouTube Data API",
    "verified_at": "2026-08-15T13:40:00+09:00",
    "track_view_ceiling": 1500000,
    "channel_view_ceiling": 5000000,
    "queries": ["korean indie dream pop official audio"]
  },
  "tracks": [
    {
      "video_id": "abcdefghijk",
      "title": "Track title",
      "artist": "Artist name",
      "views": 48210,
      "channel_views": 910000,
      "duration_seconds": 226,
      "role": "entry",
      "fit": "core",
      "why": "현재 긴장을 받아주되 보컬이 앞에 나오지 않아 첫 진입에 둔다."
    }
  ]
}
```

## 필수 규칙

- `scene`: `deep-focus`, `debug-loop`, `mechanical`, `review-writing`, `ship`, `recovery` 중 하나.
- `steer`: `push`, `hold`, `cool-down` 중 하나.
- `energy`: 0~100 정수 세 개. 시작·정점·도착.
- `tracks`: 5~10곡 권장, 빌더 허용 범위는 3~12곡.
- `video_id`: 검증된 11자리 YouTube 영상 ID.
- `role`: `entry`, `lock`, `turn`, `landing` 중 하나.
- `fit`: `core`, `adjacent`, `wildcard`, `gateway` 중 하나.
- `views`, `channel_views`: 확인하지 못했으면 `null`. 추측 숫자를 넣지 않는다.
- 같은 `video_id`와 같은 아티스트를 중복하지 않는다.
- `why`: 곡 평론이 아니라 세션 흐름에서 이 위치에 둔 이유.
