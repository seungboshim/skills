#!/usr/bin/env python3
"""Serve one generated station on loopback so YouTube receives an HTTP referer."""

from __future__ import annotations

import argparse
import functools
import http.server
import sys
import webbrowser
from pathlib import Path


class QuietHandler(http.server.SimpleHTTPRequestHandler):
    def log_message(self, format: str, *args: object) -> None:
        return


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--file", required=True)
    parser.add_argument("--port", type=int, default=0, help="0 chooses a free local port")
    parser.add_argument("--open", action="store_true", dest="open_browser")
    parser.add_argument("--check", action="store_true", help="validate inputs and exit")
    args = parser.parse_args()
    station = Path(args.file).resolve()
    if not station.is_file() or station.suffix.lower() != ".html":
        print(f"serve_station: HTML file not found: {station}", file=sys.stderr)
        return 1
    if not 0 <= args.port <= 65535:
        print("serve_station: --port must be between 0 and 65535", file=sys.stderr)
        return 2
    if args.check:
        print(station)
        return 0

    handler = functools.partial(QuietHandler, directory=str(station.parent))
    try:
        server = http.server.ThreadingHTTPServer(("127.0.0.1", args.port), handler)
    except OSError as error:
        print(f"serve_station: cannot bind local server: {error}", file=sys.stderr)
        return 1
    port = server.server_address[1]
    url = f"http://127.0.0.1:{port}/{station.name}"
    print(url, flush=True)
    if args.open_browser:
        webbrowser.open(url)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
