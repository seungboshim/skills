#!/usr/bin/env python3
"""Validate station JSON and render the bundled Diggz Radio player."""

from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path
from typing import Any


VIDEO_ID_RE = re.compile(r"^[A-Za-z0-9_-]{11}$")
SCENES = {"deep-focus", "debug-loop", "mechanical", "review-writing", "ship", "recovery"}
STEERS = {"push", "hold", "cool-down"}
ROLES = {"entry", "lock", "turn", "landing"}
FITS = {"core", "adjacent", "wildcard", "gateway"}


def require_text(data: dict[str, Any], key: str, limit: int) -> str:
    value = data.get(key)
    if not isinstance(value, str) or not value.strip():
        raise ValueError(f"{key} must be a non-empty string")
    value = value.strip()
    if len(value) > limit:
        raise ValueError(f"{key} is too long (max {limit})")
    return value


def optional_count(value: Any, key: str) -> int | None:
    if value is None:
        return None
    if isinstance(value, bool) or not isinstance(value, int) or value < 0:
        raise ValueError(f"{key} must be a non-negative integer or null")
    return value


def validate(raw: Any) -> dict[str, Any]:
    if not isinstance(raw, dict):
        raise ValueError("station JSON must be an object")
    title = require_text(raw, "title", 80)
    task = require_text(raw, "task", 160)
    brief = require_text(raw, "brief", 240)
    scene = raw.get("scene")
    steer = raw.get("steer")
    if scene not in SCENES:
        raise ValueError(f"scene must be one of: {', '.join(sorted(SCENES))}")
    if steer not in STEERS:
        raise ValueError(f"steer must be one of: {', '.join(sorted(STEERS))}")

    energy = raw.get("energy")
    if (
        not isinstance(energy, list)
        or len(energy) != 3
        or any(isinstance(value, bool) or not isinstance(value, int) or not 0 <= value <= 100 for value in energy)
    ):
        raise ValueError("energy must contain exactly three integers between 0 and 100")

    raw_tracks = raw.get("tracks")
    if not isinstance(raw_tracks, list) or not 3 <= len(raw_tracks) <= 12:
        raise ValueError("tracks must contain between 3 and 12 items")

    seen_ids: set[str] = set()
    seen_artists: set[str] = set()
    tracks: list[dict[str, Any]] = []
    for index, item in enumerate(raw_tracks, start=1):
        if not isinstance(item, dict):
            raise ValueError(f"track {index} must be an object")
        video_id = require_text(item, "video_id", 11)
        if not VIDEO_ID_RE.fullmatch(video_id):
            raise ValueError(f"track {index} has an invalid YouTube video_id")
        if video_id in seen_ids:
            raise ValueError(f"duplicate video_id: {video_id}")
        seen_ids.add(video_id)

        artist = require_text(item, "artist", 100)
        artist_key = artist.casefold()
        if artist_key in seen_artists:
            raise ValueError(f"duplicate artist: {artist}")
        seen_artists.add(artist_key)

        role = item.get("role")
        fit = item.get("fit")
        if role not in ROLES:
            raise ValueError(f"track {index} role must be one of: {', '.join(sorted(ROLES))}")
        if fit not in FITS:
            raise ValueError(f"track {index} fit must be one of: {', '.join(sorted(FITS))}")
        duration = item.get("duration_seconds")
        if isinstance(duration, bool) or not isinstance(duration, int) or not 30 <= duration <= 7200:
            raise ValueError(f"track {index} duration_seconds must be between 30 and 7200")

        tracks.append(
            {
                "video_id": video_id,
                "title": require_text(item, "title", 140),
                "artist": artist,
                "views": optional_count(item.get("views"), f"track {index} views"),
                "channel_views": optional_count(
                    item.get("channel_views"), f"track {index} channel_views"
                ),
                "duration_seconds": duration,
                "role": role,
                "fit": fit,
                "why": require_text(item, "why", 240),
                "youtube_url": f"https://www.youtube.com/watch?v={video_id}",
                "youtube_music_url": f"https://music.youtube.com/watch?v={video_id}",
            }
        )

    roles = {track["role"] for track in tracks}
    if "entry" not in roles or "landing" not in roles:
        raise ValueError("the queue needs at least one entry and one landing track")

    discovery = raw.get("discovery") if isinstance(raw.get("discovery"), dict) else {}
    total_seconds = sum(track["duration_seconds"] for track in tracks)
    verified = sum(track["views"] is not None for track in tracks)
    return {
        "title": title,
        "scene": scene,
        "steer": steer,
        "task": task,
        "brief": brief,
        "energy": energy,
        "duration_minutes": round(total_seconds / 60),
        "verified_tracks": verified,
        "discovery": discovery,
        "tracks": tracks,
    }


def safe_script_json(data: dict[str, Any]) -> str:
    return (
        json.dumps(data, ensure_ascii=False, separators=(",", ":"))
        .replace("&", "\\u0026")
        .replace("<", "\\u003c")
        .replace(">", "\\u003e")
        .replace("\u2028", "\\u2028")
        .replace("\u2029", "\\u2029")
    )


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", required=True)
    parser.add_argument("--out", required=True)
    args = parser.parse_args()
    try:
        data = validate(json.loads(Path(args.input).read_text(encoding="utf-8")))
        template = (
            Path(__file__).resolve().parent.parent / "assets" / "station-template.html"
        ).read_text(encoding="utf-8")
        if "__STATION_JSON__" not in template:
            raise ValueError("station template placeholder is missing")
        rendered = template.replace("__STATION_JSON__", safe_script_json(data))
        output = Path(args.out)
        output.parent.mkdir(parents=True, exist_ok=True)
        output.write_text(rendered, encoding="utf-8")
        print(output)
        return 0
    except (OSError, json.JSONDecodeError, ValueError) as error:
        print(f"build_station: {error}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
