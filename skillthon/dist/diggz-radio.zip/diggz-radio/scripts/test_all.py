#!/usr/bin/env python3
"""Offline regression tests for discovery parsing, validation, and rendering."""

from __future__ import annotations

import json
import subprocess
import sys
import tempfile
from pathlib import Path


HERE = Path(__file__).resolve().parent
SEARCH = HERE / "diggz_search.py"
BUILD = HERE / "build_station.py"
SERVE = HERE / "serve_station.py"


def run(*args: str, expect: int = 0) -> subprocess.CompletedProcess[str]:
    result = subprocess.run(args, capture_output=True, text=True, check=False)
    if result.returncode != expect:
        raise AssertionError(
            f"expected exit {expect}, got {result.returncode}\nstdout={result.stdout}\nstderr={result.stderr}"
        )
    return result


def check(label: str, condition: bool) -> None:
    if not condition:
        raise AssertionError(label)
    print(f"  ok   {label}")


def main() -> int:
    with tempfile.TemporaryDirectory(prefix="diggz-radio-test-") as temp:
        root = Path(temp)
        fixture = {
            "searches": {
                "dreamy debug": {
                    "items": [
                        {"id": {"videoId": "AAA111bbb22"}},
                        {"id": {"videoId": "CCC333ddd44"}},
                        {"id": {"videoId": "EEE555fff66"}},
                        {"id": {"videoId": "GGG777hhh88"}}
                    ]
                }
            },
            "videos": {
                "items": [
                    {"id": "AAA111bbb22", "snippet": {"title": "Soft Signal", "channelId": "channel-a", "channelTitle": "Small Room - Topic", "publishedAt": "2026-01-02T00:00:00Z", "liveBroadcastContent": "none"}, "statistics": {"viewCount": "48000"}, "contentDetails": {"duration": "PT3M42S"}, "status": {"embeddable": True, "privacyStatus": "public"}},
                    {"id": "CCC333ddd44", "snippet": {"title": "Bright Exit", "channelId": "channel-b", "channelTitle": "Large Door", "publishedAt": "2025-11-02T00:00:00Z", "liveBroadcastContent": "none"}, "statistics": {"viewCount": "820000"}, "contentDetails": {"duration": "PT4M01S"}, "status": {"embeddable": True, "privacyStatus": "public"}},
                    {"id": "EEE555fff66", "snippet": {"title": "Indie focus playlist mix", "channelId": "channel-c", "channelTitle": "Mix Farm", "publishedAt": "2025-01-02T00:00:00Z", "liveBroadcastContent": "none"}, "statistics": {"viewCount": "1200"}, "contentDetails": {"duration": "PT10M"}, "status": {"embeddable": True, "privacyStatus": "public"}},
                    {"id": "GGG777hhh88", "snippet": {"title": "Short Spark", "channelId": "channel-d", "channelTitle": "Tiny", "publishedAt": "2026-01-03T00:00:00Z", "liveBroadcastContent": "none"}, "statistics": {"viewCount": "900"}, "contentDetails": {"duration": "PT40S"}, "status": {"embeddable": True, "privacyStatus": "public"}}
                ]
            },
            "channels": {
                "items": [
                    {"id": "channel-a", "statistics": {"viewCount": "900000"}},
                    {"id": "channel-b", "statistics": {"viewCount": "9000000"}},
                    {"id": "channel-c", "statistics": {"viewCount": "12000"}},
                    {"id": "channel-d", "statistics": {"viewCount": "9000"}}
                ]
            }
        }
        fixture_path = root / "fixture.json"
        fixture_path.write_text(json.dumps(fixture), encoding="utf-8")
        candidates_path = root / "candidates.json"
        run(sys.executable, str(SEARCH), "--query", "dreamy debug", "--fixture", str(fixture_path), "--out", str(candidates_path))
        candidates = json.loads(candidates_path.read_text(encoding="utf-8"))["candidates"]
        print("diggz-radio 자기 점검")
        check("엄격 저점 후보를 남긴다", candidates[0]["video_id"] == "AAA111bbb22")
        check("채널 상한 초과 후보는 gateway다", candidates[1]["dig_tier"] == "gateway")
        check("mix 제목을 제외한다", all(item["video_id"] != "EEE555fff66" for item in candidates))
        check("90초 미만 영상을 제외한다", all(item["video_id"] != "GGG777hhh88" for item in candidates))

        station = {
            "title": "Debug </script><script>alert(1)</script>",
            "scene": "debug-loop",
            "steer": "cool-down",
            "task": "retry callback 추적",
            "brief": "steady and warm",
            "energy": [42, 56, 38],
            "discovery": {"source": "fixture"},
            "tracks": [
                {"video_id": "AAA111bbb22", "title": "Soft Signal", "artist": "Small Room", "views": 48000, "channel_views": 900000, "duration_seconds": 222, "role": "entry", "fit": "core", "why": "긴장을 받아주며 진입한다."},
                {"video_id": "CCC333ddd44", "title": "Bright Exit", "artist": "Large Door", "views": 820000, "channel_views": 9000000, "duration_seconds": 241, "role": "turn", "fit": "gateway", "why": "중반을 살짝 들어 올린다."},
                {"video_id": "III999jjj00", "title": "Quiet Merge", "artist": "Third Place", "views": None, "channel_views": None, "duration_seconds": 205, "role": "landing", "fit": "adjacent", "why": "마지막에 에너지를 낮춘다."}
            ]
        }
        station_path = root / "station.json"
        station_path.write_text(json.dumps(station), encoding="utf-8")
        html_path = root / "station.html"
        run(sys.executable, str(BUILD), "--input", str(station_path), "--out", str(html_path))
        html = html_path.read_text(encoding="utf-8")
        check("공식 IFrame Player를 로드한다", "youtube.com/iframe_api" in html)
        check("자동재생 파라미터가 없다", "autoplay" not in html.lower())
        check("스크립트 종료 문자열을 이스케이프한다", "</script><script>alert(1)</script>" not in html)
        check("YouTube Music 핸드오프가 있다", "music.youtube.com/watch?v=" in html)
        check("서버 입력 검사를 통과한다", run(sys.executable, str(SERVE), "--file", str(html_path), "--check").returncode == 0)

        station["tracks"][2]["artist"] = "Small Room"
        station_path.write_text(json.dumps(station), encoding="utf-8")
        failed = run(sys.executable, str(BUILD), "--input", str(station_path), "--out", str(html_path), expect=1)
        check("같은 아티스트 중복을 거부한다", "duplicate artist" in failed.stderr)

    print("전부 통과")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
