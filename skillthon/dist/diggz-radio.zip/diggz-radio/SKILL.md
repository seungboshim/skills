---
name: diggz-radio
description: >
  지금 하는 개발 작업과 사용자의 기분을 읽어 30~90분짜리 인디 음악 에너지 곡선을 만들고,
  조회수가 낮은 실제 YouTube 트랙을 디깅해 한 번 클릭으로 재생되는 로컬 라디오를 연다.
  유명곡 추천보다 새로운 아티스트 발견이 목적이다. 트리거: "/diggz-radio", "개발 플리",
  "코딩할 때 들을 음악", "집중 음악 틀어줘", "기분에 맞는 플레이리스트", "인디 디깅",
  "버그 잡을 때 들을 노래", "작업 음악 골라줘", "coding playlist", "indie work radio".
  특정 노래의 정보만 묻거나 기존 플레이리스트를 요약할 때는 쓰지 않는다.
compatibility: Python 3.10+, 브라우저, 인터넷 필요. 자동 디깅에는 YouTube Data API 키 또는 웹 검색 도구가 필요하다.
license: MIT
metadata:
  author: seungboshim
  version: "1.0.0"
  locale: ko
---

# Diggz Radio — Mood Compiler

코드 상태를 인디 플레이리스트로 컴파일한다.

이 스킬은 기분에 맞는 유명곡을 나열하는 추천기가 아니다. 지금 하는 작업의 인지 부하와
사용자가 원하는 방향을 읽고, 아직 덜 알려진 실제 트랙을 30~90분짜리 흐름으로 배열한 뒤
YouTube 공식 플레이어가 들어간 로컬 라디오를 연다.

진행은 다섯 단계다. 작업 장면 읽기 → 음악 브리프 → 디깅 → 흐름 편집 → 재생.

## 1. 작업 장면 읽기

사용자가 이미 기분과 작업을 말했으면 다시 묻지 않는다. 개발 저장소 안이라면 코드 내용 대신
다음 메타데이터만 읽어 장면을 보강한다.

```bash
git branch --show-current
git status --short
git diff --stat
git log -5 --pretty=format:'%h %s'
```

코드 본문, 환경 변수, 세션 원문은 음악 추천에 필요하지 않다. 기본값으로 읽지 않는다.

장면을 아래 여섯 개 중 하나로 잡는다. 판단 기준은 `references/music-logic.md`를 읽는다.

- `deep-focus`: 설계·복잡한 구현
- `debug-loop`: 같은 실패를 반복해 추적 중
- `mechanical`: 마이그레이션·반복 수정·정리
- `review-writing`: 리뷰·문서·기획
- `ship`: 테스트가 통과했고 마무리·배포 중
- `recovery`: 지쳤거나 과열되어 진정이 먼저

정보가 부족하면 질문은 하나만 한다.

> 지금 음악이 밀어줬으면 해, 붙잡아줬으면 해, 아니면 식혀줬으면 해?

## 2. 음악 브리프 만들기

`references/music-logic.md`의 표를 적용해 이 형식으로 먼저 짧게 선언한다.

```text
SCENE  debug-loop
STEER  cool-down
ARC    42 → 56 → 38
WORDS  low
TEXTURE steady / warm / no abrupt drops
DIG    70% 정합 · 20% 인접 · 10% 와일드카드
TIME   50 min
```

사용자의 현재 기분과 원하는 기분을 구분한다. 우울하다고 우울한 곡만 이어 붙이지 않는다.
음악은 상태를 복제하는 게 아니라 세션의 방향을 만든다.

## 3. 실제 트랙 디깅

트랙·아티스트·YouTube ID를 지어내지 않는다. 검증된 ID가 없으면 라디오를 만들지 말고 필요한
연결이나 입력을 알린다.

### A. YouTube Data API 키가 있을 때 — 권장

브리프에서 검색어 2~3개를 만든다. 장르 이름 하나보다 질감·지역·형식을 같이 쓴다.

```bash
python3 "<skill-base>/scripts/diggz_search.py" \
  --query "korean indie dream pop official audio low vocal" \
  --query "seoul shoegaze instrumental official audio" \
  --region KR \
  --out /tmp/diggz-radio-candidates.json
```

스크립트는 `YOUTUBE_API_KEY`를 환경 변수에서 읽는다. 키를 명령줄, 결과, 로그에 넣지 않는다.
기본 디깅 상한은 곡 150만 조회·채널 500만 조회이고, 영상 길이는 90초~15분이다.

### B. 웹 검색 도구가 있을 때

YouTube 영상 페이지로 범위를 제한해 브리프의 검색어를 찾는다. 후보마다 영상 ID·제목·아티스트를
실제 페이지에서 확인한다. 조회수를 확인하지 못한 후보는 `views: null`로 두고 **저점 확인 안 됨**으로
표시한다. 숫자를 추측하지 않는다.

### C. 둘 다 없을 때

사용자에게 좋아하는 인디 트랙이나 YouTube 링크 2~3개만 받아 씨앗으로 쓴다. 검색 결과 URL을
열어주는 것까지는 가능하지만, 검증하지 못한 곡을 자동 큐에 넣지는 않는다.

### 선택 규칙

- 5~10곡, 30~90분. 같은 아티스트는 한 번만 쓴다.
- 70%는 브리프에 정확히 맞고, 20%는 인접 장르, 10%는 한 곡의 와일드카드다.
- 조회수만 낮다고 좋은 디깅은 아니다. 장면 적합도와 임베드 가능 여부가 먼저다.
- 상한을 넘는 곡을 꼭 써야 하면 `gateway`라고 표시하고 한 곡만 둔다.
- 제목에 mix·playlist·full album·reaction이 있는 영상은 트랙 큐에서 뺀다.
- 라이브·Shorts·90초 미만·15분 초과 영상은 기본적으로 뺀다.
- “인디”를 계약 형태로 단정하지 않는다. 여기서 인디는 **발견 규모가 작은 음악**이라는 운영상
  정의이고, 조회수·채널 규모를 근거로 보여준다.

## 4. 세션 흐름 편집

곡을 점수순으로 나열하지 않는다. `entry → lock → turn → landing` 역할로 배치한다.

- `entry`: 첫 1~2곡. 지금 기분을 거부하지 않고 들어간다.
- `lock`: 세션의 가장 안정적인 구간. 갑작스러운 템포·보컬 변화가 적다.
- `turn`: 에너지를 올리거나 식히는 한 곡. 와일드카드는 보통 여기 둔다.
- `landing`: 마지막 1~2곡. 다음 행동으로 넘어갈 여백을 만든다.

각 곡에 “좋아서”가 아니라 **이 위치에 놓인 이유**를 한 문장으로 쓴다.

최종 JSON은 `references/station-schema.md`를 따른다. 완성 뒤 빌더를 실행한다.

```bash
python3 "<skill-base>/scripts/build_station.py" \
  --input /tmp/diggz-radio-station.json \
  --out /tmp/diggz-radio/station.html
```

## 5. 재생

로컬 파일을 직접 열지 않는다. YouTube 임베드가 요구하는 출처 헤더를 보내도록 로컬 HTTP 서버로
연다.

```bash
python3 "<skill-base>/scripts/serve_station.py" \
  --file /tmp/diggz-radio/station.html --open
```

서버는 `127.0.0.1`에만 바인딩한다. 라디오 화면이 열려도 소리는 나지 않는다. 사용자가
`세션 시작`을 눌러야 재생한다. 에이전트가 몰래 소리를 시작하면 안 된다.

사용자가 YouTube Music에서 이어 듣고 싶으면 화면의 `YouTube Music에서 열기`를 누른다.
각 곡은 `https://music.youtube.com/watch?v=<video_id>`로 넘긴다.

## 결과 보고

라디오를 연 뒤 대화에는 이것만 남긴다.

```text
Diggz Radio · DEBUG LOOP / COOL-DOWN
8 tracks · 52 min · 저점 확인 7/8
에너지 42 → 56 → 38

한 줄: 초반엔 지금의 긴장을 받아주고, 중반엔 일정한 질감으로 잠근 뒤, 마지막 두 곡에서 식힌다.
```

곡 목록을 대화에 또 길게 복사하지 않는다. 화면에서 보면 된다.

## 실패와 안전 경계

- 전용 YouTube Music 공식 API가 있다고 가정하지 않는다.
- 비공식 YouTube Music 내부 API, 쿠키 복사, `ytmusicapi`, 스크래핑, 다운로드 도구를 쓰지 않는다.
- 사용자 계정에 플레이리스트를 만들거나 수정하지 않는다. 그 동작은 OAuth와 별도 승인이 필요한
  후속 기능이다.
- YouTube 플레이어를 가리거나 컨트롤을 숨기지 않는다. 한 화면에서 한 플레이어만 재생한다.
- API 키를 출력·저장하지 않는다. 검색 결과는 `/tmp`에 두고 30일 이상 보존하지 않는다.
- 재생 실패·임베드 금지 영상은 건너뛰고 어떤 곡이 빠졌는지 알린다.
- 음악 감상을 Hype 포인트나 보상과 연결하지 않는다. 이 스킬은 청취량을 조작하거나 보상하지 않는다.
