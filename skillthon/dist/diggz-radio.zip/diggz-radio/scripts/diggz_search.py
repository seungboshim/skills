#!/usr/bin/env python3
"""Discover low-view music videos through the official YouTube Data API.

The API key is read only from YOUTUBE_API_KEY. It is never accepted as a CLI
argument and never written to output. Use --fixture for offline tests.
"""

from __future__ import annotations

import argparse
import json
import math
import os
import re
import sys
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path
from typing import Any, Iterable


API_BASE = "https://www.googleapis.com/youtube/v3"
VIDEO_ID_RE = re.compile(r"^[A-Za-z0-9_-]{11}$")
DURATION_RE = re.compile(r"^PT(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?$")
BANNED_TITLE = re.compile(r"\b(mix|playlist|full album|reaction|1\s*hour|2\s*hour)\b", re.I)


def chunks(items: list[str], size: int = 50) -> Iterable[list[str]]:
    for index in range(0, len(items), size):
        yield items[index : index + size]


def parse_duration(value: str) -> int | None:
    match = DURATION_RE.fullmatch(value or "")
    if not match:
        return None
    hours, minutes, seconds = (int(part or 0) for part in match.groups())
    return hours * 3600 + minutes * 60 + seconds


def as_int(value: Any) -> int | None:
    try:
        return int(value)
    except (TypeError, ValueError):
        return None


def clean_artist(channel_title: str) -> str:
    return re.sub(r"\s*-\s*Topic\s*$", "", channel_title, flags=re.I).strip()


class YoutubeClient:
    def __init__(self, api_key: str) -> None:
        self.api_key = api_key

    def get(self, resource: str, params: dict[str, str]) -> dict[str, Any]:
        query = urllib.parse.urlencode({**params, "key": self.api_key})
        request = urllib.request.Request(
            f"{API_BASE}/{resource}?{query}",
            headers={"Accept": "application/json", "User-Agent": "diggz-radio/1.0"},
        )
        try:
            with urllib.request.urlopen(request, timeout=20) as response:
                return json.load(response)
        except urllib.error.HTTPError as error:
            detail = error.read(300).decode("utf-8", "replace")
            raise RuntimeError(f"YouTube {resource} failed ({error.code}): {detail}") from error
        except urllib.error.URLError as error:
            raise RuntimeError(f"YouTube {resource} network error: {error.reason}") from error


class FixtureClient:
    def __init__(self, fixture: dict[str, Any]) -> None:
        self.fixture = fixture

    def get(self, resource: str, params: dict[str, str]) -> dict[str, Any]:
        if resource == "search":
            searches = self.fixture.get("searches", {})
            if params["q"] not in searches:
                raise RuntimeError(f"fixture has no search response for: {params['q']}")
            return searches[params["q"]]
        return self.fixture.get(resource, {"items": []})


def scarcity(value: int | None, ceiling: int) -> float:
    if value is None:
        return 0.0
    return max(0.0, 1.0 - math.log10(value + 1) / math.log10(ceiling + 1))


def discover(args: argparse.Namespace) -> dict[str, Any]:
    if args.fixture:
        client: YoutubeClient | FixtureClient = FixtureClient(
            json.loads(Path(args.fixture).read_text(encoding="utf-8"))
        )
        source = "fixture"
    else:
        api_key = os.environ.get("YOUTUBE_API_KEY", "")
        if not api_key:
            raise RuntimeError("YOUTUBE_API_KEY is not set; use an environment variable, not a CLI argument")
        client = YoutubeClient(api_key)
        source = "YouTube Data API"

    found: dict[str, dict[str, Any]] = {}
    for query_index, query in enumerate(args.query):
        payload = client.get(
            "search",
            {
                "part": "snippet",
                "q": query,
                "type": "video",
                "videoCategoryId": "10",
                "videoEmbeddable": "true",
                "safeSearch": "strict",
                "maxResults": str(args.max_per_query),
                "regionCode": args.region,
                "relevanceLanguage": args.language,
            },
        )
        for rank, raw in enumerate(payload.get("items", [])):
            video_id = (raw.get("id") or {}).get("videoId")
            if not isinstance(video_id, str) or not VIDEO_ID_RE.fullmatch(video_id):
                continue
            existing = found.get(video_id)
            candidate_rank = query_index * args.max_per_query + rank
            if existing is None or candidate_rank < existing["rank"]:
                found[video_id] = {"rank": candidate_rank, "fit_query": query}

    if not found:
        return {"source": source, "queries": args.query, "candidates": []}

    video_items: list[dict[str, Any]] = []
    video_ids = list(found)
    for batch in chunks(video_ids):
        video_items.extend(
            client.get(
                "videos",
                {"part": "snippet,statistics,contentDetails,status", "id": ",".join(batch)},
            ).get("items", [])
        )

    channel_ids = sorted(
        {
            item.get("snippet", {}).get("channelId")
            for item in video_items
            if item.get("snippet", {}).get("channelId")
        }
    )
    channel_views: dict[str, int | None] = {}
    for batch in chunks(channel_ids):
        payload = client.get("channels", {"part": "statistics", "id": ",".join(batch)})
        for item in payload.get("items", []):
            channel_views[item.get("id", "")] = as_int(item.get("statistics", {}).get("viewCount"))

    strict: list[dict[str, Any]] = []
    gateways: list[dict[str, Any]] = []
    for item in video_items:
        video_id = item.get("id")
        if video_id not in found:
            continue
        snippet = item.get("snippet", {})
        status = item.get("status", {})
        details = item.get("contentDetails", {})
        title = str(snippet.get("title") or "").strip()
        duration = parse_duration(str(details.get("duration") or ""))
        views = as_int(item.get("statistics", {}).get("viewCount"))
        channel_id = str(snippet.get("channelId") or "")
        ch_views = channel_views.get(channel_id)

        if (
            not title
            or BANNED_TITLE.search(title)
            or duration is None
            or not args.min_seconds <= duration <= args.max_seconds
            or status.get("embeddable") is False
            or status.get("privacyStatus") not in (None, "public")
            or snippet.get("liveBroadcastContent") not in (None, "none")
        ):
            continue

        rank = found[video_id]["rank"]
        rank_fit = max(0.0, 1.0 - rank / max(1, len(args.query) * args.max_per_query))
        score = round(
            rank_fit * 0.55
            + scarcity(views, args.track_view_ceiling) * 0.30
            + scarcity(ch_views, args.channel_view_ceiling) * 0.15,
            4,
        )
        is_strict = (
            views is not None
            and views <= args.track_view_ceiling
            and ch_views is not None
            and ch_views <= args.channel_view_ceiling
        )
        candidate = {
            "video_id": video_id,
            "title": title,
            "artist": clean_artist(str(snippet.get("channelTitle") or "Unknown artist")),
            "views": views,
            "channel_views": ch_views,
            "duration_seconds": duration,
            "published_at": snippet.get("publishedAt"),
            "fit_query": found[video_id]["fit_query"],
            "dig_tier": "core" if is_strict else "gateway",
            "score": score,
            "youtube_url": f"https://www.youtube.com/watch?v={video_id}",
            "youtube_music_url": f"https://music.youtube.com/watch?v={video_id}",
        }
        (strict if is_strict else gateways).append(candidate)

    strict.sort(key=lambda item: item["score"], reverse=True)
    gateways.sort(key=lambda item: item["score"], reverse=True)
    candidates = strict + gateways[: args.gateway_limit]
    return {
        "source": source,
        "queries": args.query,
        "region": args.region,
        "track_view_ceiling": args.track_view_ceiling,
        "channel_view_ceiling": args.channel_view_ceiling,
        "candidates": candidates,
    }


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--query", action="append", required=True, help="2-3 discovery queries")
    parser.add_argument("--region", default="KR")
    parser.add_argument("--language", default="ko")
    parser.add_argument("--max-per-query", type=int, default=12)
    parser.add_argument("--track-view-ceiling", type=int, default=1_500_000)
    parser.add_argument("--channel-view-ceiling", type=int, default=5_000_000)
    parser.add_argument("--min-seconds", type=int, default=90)
    parser.add_argument("--max-seconds", type=int, default=900)
    parser.add_argument("--gateway-limit", type=int, default=2)
    parser.add_argument("--fixture", help="offline fixture JSON")
    parser.add_argument("--out", required=True)
    args = parser.parse_args()
    if not 1 <= len(args.query) <= 3:
        parser.error("use between 1 and 3 --query values")
    for name in (
        "max_per_query",
        "track_view_ceiling",
        "channel_view_ceiling",
        "min_seconds",
        "max_seconds",
    ):
        if getattr(args, name) <= 0:
            parser.error(f"--{name.replace('_', '-')} must be positive")
    if args.min_seconds >= args.max_seconds:
        parser.error("--min-seconds must be smaller than --max-seconds")
    return args


def main() -> int:
    args = parse_args()
    try:
        result = discover(args)
        output = Path(args.out)
        output.parent.mkdir(parents=True, exist_ok=True)
        output.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        print(output)
        print(f"{len(result['candidates'])} candidates", file=sys.stderr)
        return 0
    except (RuntimeError, OSError, json.JSONDecodeError) as error:
        print(f"diggz_search: {error}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
