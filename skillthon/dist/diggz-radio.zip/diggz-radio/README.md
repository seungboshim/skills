# Diggz Radio — Mood Compiler

> 코드 상태를 인디 플레이리스트로 컴파일한다.

`diggz-radio`는 “집중 음악 추천해줘”에 유명곡 목록을 답하는 스킬이 아닙니다. 현재 개발 작업의
인지 부하와 사용자가 원하는 감정 방향을 읽고, 덜 알려진 실제 YouTube 트랙을 디깅해
`entry → lock → turn → landing` 흐름으로 편집한 뒤 한 번 클릭으로 재생되는 로컬 라디오를
만듭니다.

## 이런 식으로 씁니다

```text
/diggz-radio 테스트가 계속 깨져서 과열됐어. 한국 인디 위주로 45분,
가사는 적고 너무 처지지는 않게 틀어줘.
```

스킬은 `debug-loop / cool-down` 같은 세션 장면을 먼저 잡고, 실제 영상 ID와 조회수를 검증한
5~10곡을 에너지 곡선으로 배치합니다. 화면이 열려도 소리는 나지 않으며, 사용자가 `세션 시작`을
눌러야 공식 YouTube IFrame Player가 재생됩니다. 각 곡은 YouTube Music으로 넘겨서 이어 들을
수 있습니다.

## 왜 별도 YouTube Music 연동이 없나요?

기본 구현은 비공식 YouTube Music 내부 API나 브라우저 쿠키를 사용하지 않습니다. 재생은 공식
YouTube IFrame Player, 자동 디깅은 공식 YouTube Data API 또는 검증 가능한 웹 검색을 씁니다.
사용자 계정에 영구 플레이리스트를 쓰는 기능은 OAuth와 별도 승인이 필요한 후속 기능으로
분리했습니다.

## 구성

- `SKILL.md`: 에이전트가 따르는 전체 워크플로와 안전 경계
- `scripts/diggz_search.py`: YouTube Data API 기반 저점 후보 검색·검증
- `scripts/build_station.py`: station JSON 검증과 플레이어 HTML 생성
- `scripts/serve_station.py`: Referer를 제공하는 loopback 전용 로컬 서버
- `assets/station-template.html`: 공식 IFrame API를 쓰는 라디오 UI
- `references/`: 작업 장면별 음악 로직과 station 스키마
- `evals/evals.json`: 일반·경계·적대 요청 평가셋

모든 스크립트는 Python 표준 라이브러리만 사용합니다.

## 직접 검증

```bash
python3 scripts/test_all.py
```

검색 필터, HTML 인젝션 방어, 자동재생 금지, 중복 아티스트 거부, YouTube Music 핸드오프를
네트워크 없이 검사합니다.

